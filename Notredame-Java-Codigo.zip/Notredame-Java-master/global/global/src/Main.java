import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        menu();

    }

    public static void menu() {
        //Login para testes
        var loginTeste = new Login("teste@teste.com", "senha", "teste", 1199999999, "endereço 123");
        loginTeste.getPacientes().add(new Paciente("paciente",
                new FichaMedica(26, "F", false, "nenhuma",
                        "nenhuma", "A-", 58, 1.65, false, false)));


        //Variável para armazenar os Logins cadastrados
        var logins = new ArrayList<Login>();
        logins.add(loginTeste);
        System.out.println("=====Bem-vindo(a) ao portal da Notredame=====");
        while (true) {
            try {
                System.out.println("1.Cadastrar\r\n2.Fazer login\n\r3.Sair");
                var scanner = new Scanner(System.in);
                var opcao = scanner.nextInt();
                scanner.nextLine();
                if (opcao == 1) {
                    //Chama o método para cadastrar um novo Login e adiciona o novo Login na lista de Logins
                    logins.add(criarLogin(logins));
                } else if (opcao == 2) {
                    var continuar = 0;
                    if (!logins.isEmpty()) {
                        while (true) {
                            //Pega as informações de login
                            System.out.println("Digite seu email cadastrado: ");
                            String username = scanner.nextLine();
                            System.out.println("Digite a senha: ");
                            String senha = scanner.nextLine();
                            //Verifica o login usando o método verificarLogin
                            if (verificarLogin(logins, username, senha)) {
                                //Salva em uma variável o login que foi logado
                                Login loginLogado = (saberLogin(logins, username, senha));
                                System.out.println("Login efetuado com sucesso");
                                while (true) {
                                    try {
                                        //Menu do login
                                        System.out.println("1. Preencher/Atualizar fichas médicas\n\r" +
                                                "2. Visualizar fichas médicas\n\r" +
                                                "3. Ponto socorro\n\r4. Emergência\n\r5. Sair");
                                        var escolha = scanner.nextInt();
                                        scanner.nextLine();
                                        if (escolha == 1) {
                                            for (Login l : logins) {
                                                if (l.equals(loginLogado)) {
                                                    //Chama o metodo para cadastrar uma ficha medica
                                                    System.out.println(l.cadastrarFicha());
                                                }

                                            }


                                        } else if (escolha == 2) {
                                            for (Login l : logins) {

                                                if (l.equals(loginLogado)) {
                                                    //Verifica se existe algum paciente na lista do usuário
                                                    if (!l.getPacientes().isEmpty()) {
                                                        //Mostra no console as fichas medicas dos pacientes que estão na lista do usuário
                                                        System.out.println("Fichas Médicas:");
                                                        for (Paciente p : l.getPacientes()) {
                                                            System.out.println(p);
                                                        }
                                                    } else {
                                                        System.out.println("Você ainda não possui nenhuma ficha cadastrada");
                                                    }

                                                }

                                            }

                                        } else if (escolha == 3) {
                                            loginLogado.pontoSocorro();
                                        } else if (escolha == 4) {
                                            loginLogado.emergencia();
                                        } else if (escolha == 5) {
                                            break;
                                        } else {
                                            throw new RuntimeException();
                                        }

                                    } catch (Exception e) {
                                        System.out.println("Digite um número de 1 à 5");

                                    }

                                }
                                break;
                            } else {
                                System.out.println("Username ou senha inválido\n\r1. Voltar ao menu principal\n\rQualquer outro número para tentar novamente");
                                continuar = scanner.nextInt();
                                scanner.nextLine();
                                if (continuar == 1) {
                                    break;
                                } else {
                                    continue;
                                }


                            }
                        }
                    } else {
                        System.out.println("Nenhum cadastro registrado, crie um cadastro  para realizar o login");

                    }


                } else if (opcao == 3) {
                    System.out.println("Encerrando o programa");
                    break;
                } else {
                    throw new RuntimeException();
                }

            } catch (Exception e) {
                System.out.println("Digite um número de 1 à 3");
            }
        }
    }

    // Método para verificar se o Login que o usuário inseriu está correto
    public static boolean verificarLogin(ArrayList<Login> logins, String username, String senha) {
        for (Login l : logins) {

            //Verifica se o username inserido é igual ao email cadastrado
            if (l.getEmail().equals(username)) {
                //Verifica se a senha inserida corresponde a senha cadastrada
                if (l.getSenha().equals(senha)) {
                    return true;

                }
            }

        }
        return false;
    }

    //Método para poder salvar o Login em uma variável
    public static Login saberLogin(ArrayList<Login> logins, String username, String senha) {
        for (Login l : logins) {

            if (l.getEmail().equals(username)) {
                if (l.getSenha().equals(senha)) {

                    //retorna o Login que corresponde ao username e senha inseridos
                    return l;

                }
            }

        }
        return null;
    }

    //Método para realizar um cadastro
    public static Login criarLogin(ArrayList<Login> logins) {

        var scanner = new Scanner(System.in);
        Login novoLogin = new Login();
        System.out.println("Nome: ");
        novoLogin.setNome(scanner.nextLine());


        while (true) {
            try {
                System.out.println("Telefone ou celular: ");
                novoLogin.setTelefone(scanner.nextInt());
                scanner.nextLine();
                break;
            } catch (Exception e) {
                scanner.nextLine();
                System.out.println("Digite apenas os números com o DDD");
            }
        }

        while (true) {
            try {
                System.out.println("Email: ");
                var email = scanner.nextLine();
                var achou = 0;
                if (email.contains("@") && email.contains(".com")) {


                    if (!logins.isEmpty()) {
                        for (Login l : logins) {
                            //Confere se o email já foi cadastrado
                            if (l.getEmail().equals(email)) {
                                System.out.println("Este email já foi cadastrado");
                                achou = 1;
                                break;
                            }
                        }
                    }
                    if (achou == 0) {
                        novoLogin.setEmail(email);
                        break;
                    }
                } else {
                    throw new RuntimeException();
                }
            } catch (Exception e) {
                System.out.println("Digite um endereço de email válido");
            }
        }
        System.out.println("endereço: ");
        novoLogin.setEndereco(scanner.nextLine());

        System.out.println("Crie uma senha: ");
        novoLogin.setSenha(scanner.nextLine());
        System.out.println(novoLogin);
        //Retorna o Login cadastrado
        return novoLogin;


    }

}









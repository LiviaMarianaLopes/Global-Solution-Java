import java.util.Scanner;

public class FichaTriagem extends Ficha {
    private String sintomas;
    private String medicamentos;

    public FichaTriagem(int idade, String sexo, boolean gravidez, String sintomas, String medicamentos) {
        super(idade, sexo, gravidez);
        this.sintomas = sintomas;
        this.medicamentos = medicamentos;
    }

    public FichaTriagem() {
    }

    public String getSintomas() {
        return sintomas;
    }

    public void setSintomas(String sintomas) {
        this.sintomas = sintomas;
    }

    public String getMedicamentos() {
        return medicamentos;
    }

    public void setMedicamentos(String medicamentos) {
        this.medicamentos = medicamentos;
    }

//metodo para cadastrar uma ficha de triagem para um paciente já cadastrado
    public Ficha cadastrarFicha(FichaMedica ficha) {
        var scanner = new Scanner(System.in);
        FichaTriagem novaFicha = new FichaTriagem();
        System.out.println("Por favor insira as informações do comparecimento: ");
        novaFicha.setSintomas(scanner.nextLine());
        System.out.println("Tomou alguma medicação? se sim qual? ");
        novaFicha.setMedicamentos(scanner.nextLine());
        System.out.println("Certo! já enviamos as informações para agilizar o processo, estamos ao seu aguardo!");
        return novaFicha;
    }

    //metodo para cadastrar uma ficha de triagem para um novo paciente
    @Override
    public void cadastrarFicha(Paciente paciente) {
        var scanner = new Scanner(System.in);
        FichaTriagem novaFicha = new FichaTriagem();
        while (true) {
            try {
                System.out.println("Sexo: F/M ");
                var sexo = scanner.nextLine();
                if (sexo.equalsIgnoreCase("f") || sexo.equalsIgnoreCase("m")) {
                    novaFicha.setSexo(sexo);
                    break;
                } else {
                    throw new RuntimeException();
                }
            } catch (Exception e) {
                System.out.println("Digite 'F' para feminino ou 'M' para masculino");
            }
        }
        if (novaFicha.getSexo().equalsIgnoreCase("f")){
            while (true) {
                try {


                    System.out.println("Está gravida? S/N");
                    var gravida = scanner.nextLine();

                    if (gravida.equalsIgnoreCase("s")) {
                        novaFicha.setGravidez(true);
                        break;
                    }
                    else if (gravida.equalsIgnoreCase("n")) {
                        novaFicha.setGravidez(false);
                        break;
                    } else {
                        throw new RuntimeException();
                    }
                }

                catch (Exception e){
                    System.out.println("Digite 'S' se estiver grávida ou 'N' se não estiver");
                }
            }
        }
        else{
            novaFicha.setGravidez(false);
        }

        while (true) {
            try {
                System.out.println("Idade: ");
                novaFicha.setIdade(scanner.nextInt());
                scanner.nextLine();
                break;
            } catch (Exception e) {
                scanner.nextLine();
                System.out.println("Insira a idade em forma númerica");
            }
        }System.out.println("Por favor insira as informações do comparecimento: ");
        novaFicha.setSintomas(scanner.nextLine());
        System.out.println("Tomou alguma medicação? se sim qual? ");
        novaFicha.setMedicamentos(scanner.nextLine());
        System.out.println("Certo! já enviamos as informações para agilizar o processo, estamos ao seu aguardo!");
        paciente.setFichaTriagem(novaFicha);

    }

    @Override
    public String toString() {
        return "Triagem{" +
                "sintomas='" + sintomas + '\'' +
                ", medicamentos='" + medicamentos + '\'' +
                '}';
    }
}

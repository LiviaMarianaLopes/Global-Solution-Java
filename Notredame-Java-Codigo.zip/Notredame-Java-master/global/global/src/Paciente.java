import java.util.Scanner;

public class Paciente {
    private String nome;
    private FichaMedica fichaMedica;
    private FichaTriagem fichaTriagem;

    public Paciente(String nome, FichaMedica fichaMedica, FichaTriagem fichaTriagem) {
        this.nome = nome;
        this.fichaMedica = fichaMedica;
        this.fichaTriagem = fichaTriagem;
    }

    public Paciente(String nome, FichaMedica fichaMedica) {
        this.nome = nome;
        this.fichaMedica = fichaMedica;
    }

    public Paciente() {
        this.fichaTriagem = new FichaTriagem();
        this.fichaMedica = new FichaMedica();
    }

    public FichaTriagem getFichaTriagem() {
        return fichaTriagem;
    }

    public void setFichaTriagem(FichaTriagem fichaTriagem) {
        this.fichaTriagem = fichaTriagem;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public FichaMedica getFichaMedica() {
        return fichaMedica;
    }

    public void setFichaMedica(FichaMedica fichaMedica) {
        this.fichaMedica = fichaMedica;
    }

    //metodo para cadastrar nome
    public void cadastrarNome(){
        var scanner = new Scanner(System.in);
        System.out.println("Nome: ");
        this.nome = scanner.nextLine();
    }


    @Override
    public String toString() {
        return "Paciente{" +
                "nome: '" + nome + '\'' +
                ", \n\rFicha Medica: " + fichaMedica +
                '}';
    }
}

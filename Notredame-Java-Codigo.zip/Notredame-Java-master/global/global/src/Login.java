import java.util.ArrayList;
import java.util.Scanner;

public class Login {
    private String email;
    private String senha;
    private String nome;
    private int telefone;
   private String endereco;
   private ArrayList  <Paciente> pacientes;

    public Login(String email, String senha, String nome, int telefone, String endereco) {
        this.email = email;
        this.senha = senha;
        this.nome = nome;
        this.telefone = telefone;
        this.endereco = endereco;
        this.pacientes = new ArrayList<>();
    }

    public Login() {
        this.pacientes = new ArrayList<>();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getTelefone() {
        return telefone;
    }

    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public ArrayList<Paciente> getPacientes() {
        return pacientes;
    }

    public void setPacientes(ArrayList<Paciente> pacientes) {
        this.pacientes = pacientes;
    }

    //Metodo para chamar uma ambulancia em casos de emergencia
    public void emergencia(){

        var scanner = new Scanner(System.in);
        while (true){
            try {
                System.out.println("Qual endereço devemos realizar o socorro?\n\r" +
                        "1. Localização atual\n\r" +
                        "2. Endereço cadastrado\n\r" +
                        "3. Outro\n\r" +
                        "4. Cancelar");
                var local = scanner.nextInt();
                scanner.nextLine();
                if (local == 3){
                    System.out.println("Digite o endereço: ");
                    scanner.nextLine();
                }
                if (local == 1 || local == 2|| local == 3){
                    System.out.println("Estamos a caminho!");
                    if (!getPacientes().isEmpty()){
                        while (true) {
                            System.out.println("Para qual paciente será o atendimento?\n\r ");
                            int cont = 0;
                            for (Paciente m : getPacientes()) {
                                System.out.println(cont + ". " + m.getNome());
                                cont += 1;
                            }

                            try {

                                System.out.println(cont + ". Outro\n\r" );
                                var resp = scanner.nextInt();
                                scanner.nextLine();
                                if (resp >= 0 && resp <= cont) {
                                    System.out.println("Já estamos nos preparando para o socorro");
                                    break;
                                }

                                else {
                                    scanner.nextLine();
                                    throw new RuntimeException();
                                }
                            } catch (Exception e) {
                                scanner.nextLine();
                                System.out.println("Digite um número de 0 à " + cont);
                            }
                            break;
                        }
                    }
                    break;
                }
                else if (local == 4){
                    break;
                }
                else{
                    throw new RuntimeException();
                }

            }
            catch (Exception e){
                scanner.nextLine();
                System.out.println("Digite um número de 1 à 4");
            }}}
    //metodo pontoSocorro para o usuario realizar uma pré triagem
    public void pontoSocorro(){
        var scanner = new Scanner(System.in);
        while (true) {
            try {
                //menu para selecionar a unidade de comparecimento
                System.out.println("Qual unidade você deseja comparecer?\n\r" +
                        "1. Rua Dr. Fernando Faleiros de Lima 2233 (Centro), Franca, SP\n\r" +
                        "2. Rua Bresser, 1954 - Mooca " +
                        "São Paulo - SP\n\r" +
                        "3. Rua Dom Alberto Gonçalves, 1500 - Vila Tamandaré " +
                        "Ribeirão Preto - SP\n\r" +
                        "4. Avenida Pereira Barreto, 846 - Baeta Neves " +
                        "São Bernardo do Campo - SP\n\r" +
                        "5. Avenida Autonomistas, 2502 - Vila Yara " +
                        "Osasco - SP\n\r" +
                        "6. Avenida Tiradentes, 1015 - Jardim Santa Edwirges " +
                        "Guarulhos - SP\n\r" +
                        "7. Cancelar");
                var unidade = scanner.nextInt();
                scanner.nextLine();
                if (unidade >= 0 && unidade <= 6) {


                    if (!getPacientes().isEmpty()) {
                        while (true) {
                            System.out.println("Para qual paciente seria o atendimento?\n\r ");
                            int cont = 0;
                            for (Paciente m : getPacientes()) {
                                System.out.println(cont + ". " + m.getNome());
                                cont += 1;
                            }
                            int sair = cont + 1;
                            try {

                                System.out.println(cont + ". Outro\n\r" + sair + ". Sair");
                                var resp = scanner.nextInt();
                                scanner.nextLine();
                                if (resp >= 0 && resp < cont) {
                                    //chama o metodo para cadastrar uma ficha de triagem para um paciente já cadastrado
                                    getPacientes().get(resp).getFichaTriagem().cadastrarFicha(getPacientes().get(resp).getFichaMedica());



                                    break;

                                } else if (resp ==  cont) {
                                    var paciente = new Paciente();
                                    paciente.cadastrarNome();
                                    //chama o metodo para cadastrar uma ficha de triagem para um novo paciente
                                    paciente.getFichaTriagem().cadastrarFicha(paciente);
                                    break;

                                } else if (resp == sair) {
                                    break;

                                } else {
                                    throw new RuntimeException();
                                }
                            } catch (Exception e) {
                                scanner.nextLine();
                                System.out.println("Digite um número de 0 à " + sair);
                            }
                            break;
                        }break;
                    } else {
                        var paciente = new Paciente();
                        paciente.cadastrarNome();
                        //chama o metodo para cadastrar uma ficha de triagem para um novo paciente
                        paciente.getFichaTriagem().cadastrarFicha(paciente);
                        break;

                    }
                }

                else if (unidade == 7) {
                    break;
                } else {
                    throw new RuntimeException();
                }
            }
            catch (Exception e){
                scanner.nextLine();
                System.out.println("Digite um número de 1 à 7");
            }

        }
    }
    //metodo para cadastrar um novo paciente
    public Paciente cadastrarPaciente() {
        var scanner = new Scanner(System.in);
        Paciente novoPaciente = new Paciente();
        System.out.println("Nome: ");
        novoPaciente.setNome(scanner.nextLine());
        //chama o metodo cadstrarFicha para cadastrar a ficha medica do paciente
        novoPaciente.getFichaMedica().cadastrarFicha(novoPaciente);
        return novoPaciente;
    }

    //Metodo para cadastrar uma ficha
    public FichaMedica cadastrarFicha (){
        var scanner = new Scanner(System.in);
        if (!getPacientes().isEmpty()) {
            while (true){
                //Usuario pode escolher qual ficha atualizar ou criar uma nova
                System.out.println("Qual ficha você gostaria de atualizar ou preencher? ");
                int cont = 0;
                for (Paciente m : getPacientes()){
                    System.out.println(cont+". "+m.getNome());
                    cont += 1;
                }
                int sair = cont +1;
                try{

                    System.out.println(cont +". Outro\n\r"+sair+". Sair");
                    var resp = scanner.nextInt();
                    scanner.nextLine();
                    if (resp >= 0 && resp < cont){
                        //Atualiza a ficha médica de um paciente, chamando o médoto cadastrar ficha de uma ficha médica
                        getPacientes().get(resp).setFichaMedica(pacientes.get(resp).getFichaMedica().cadastrarFicha(pacientes.get(resp).getFichaMedica()));
                        return getPacientes().get(resp).getFichaMedica();
                    }
                    else if (resp == cont){
                        //Cadastra um novo paciente
                        Paciente novoPaciente = cadastrarPaciente();
                        //Adiciona o novo paciente na lista de pacientes do login
                        getPacientes().add(novoPaciente);
                        return novoPaciente.getFichaMedica();
                    }

                    else if (resp == sair){
                        return null;


                    }
                    else{
                        throw new RuntimeException();
                    }
                }
                catch (Exception e){
                    scanner.nextLine();
                    System.out.println("Digite um número de 0 à "+ sair);
                }
            }
        }

        else{
            //Se o login não tiver nenhum paciente cadastrado, ele chama o metodo cadastrarPaciente
            Paciente novoPaciente = cadastrarPaciente();
            getPacientes().add(novoPaciente);
            return novoPaciente.getFichaMedica();

        }
    }

    @Override
    public String toString() {
        return "Login{"+
    " email= "+email+
    " nome= "+nome+
    " telefone=  "+telefone+
    " endereco= "+endereco+
"}";
    }
}

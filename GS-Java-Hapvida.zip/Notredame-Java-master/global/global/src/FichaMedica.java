import java.util.Scanner;

public class FichaMedica extends Ficha{

    private String alergias;
    private String condicoes;
    private String tipoSanguineo;
    private double peso;
    private double altura;
    private boolean tabagismo;
    private boolean alcool;

    public FichaMedica(int idade, String sexo, boolean gravidez, String alergias, String condicoes, String tipoSanguineo, double peso, double altura, boolean tabagismo, boolean alcool) {
        super(idade, sexo, gravidez);
        this.alergias = alergias;
        this.condicoes = condicoes;
        this.tipoSanguineo = tipoSanguineo;
        this.peso = peso;
        this.altura = altura;
        this.tabagismo = tabagismo;
        this.alcool = alcool;
    }

    public FichaMedica() {
    }

    public String getAlergias() {
        return alergias;
    }

    public void setAlergias(String alergias) {
        this.alergias = alergias;
    }

    public String getCondicoes() {
        return condicoes;
    }

    public void setCondicoes(String condicoes) {
        this.condicoes = condicoes;
    }

    public String getTipoSanguineo() {
        return tipoSanguineo;
    }

    public void setTipoSanguineo(String tipoSanguineo) {
        this.tipoSanguineo = tipoSanguineo;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public boolean isTabagismo() {
        return tabagismo;
    }

    public void setTabagismo(boolean tabagismo) {
        this.tabagismo = tabagismo;
    }

    public boolean isAlcool() {
        return alcool;
    }

    public void setAlcool(boolean alcool) {
        this.alcool = alcool;
    }

    //metodo para cadastrar uma ficha medica
    @Override
    public  void cadastrarFicha(Paciente paciente) {
        var scanner = new Scanner(System.in);
        FichaMedica novaFicha = new FichaMedica();
        while (true) {
            try {
                System.out.println("Sexo: F/M ");
                var sexo = scanner.nextLine();
                if (sexo.equalsIgnoreCase("f") || sexo.equalsIgnoreCase("m")) {
                    novaFicha.setSexo(sexo);
                    break;
                } else {
                    throw new RuntimeException();
                }
            } catch (Exception e) {
                System.out.println("Digite 'F' para feminino ou 'M' para masculino");
            }
        }
        if (novaFicha.getSexo().equalsIgnoreCase("f")){
            while (true) {
                try {


                    System.out.println("Está gravida? S/N");
                    var gravida = scanner.nextLine();

                    if (gravida.equalsIgnoreCase("s")) {
                        novaFicha.setGravidez(true);
                        break;
                    }
                    else if (gravida.equalsIgnoreCase("n")) {
                        novaFicha.setGravidez(false);
                        break;
                    } else {
                        throw new RuntimeException();
                    }
                }

                catch (Exception e){
                    System.out.println("Digite 'S' se estiver grávida ou 'N' se não estiver");
                }
            }
        }
        else{
            novaFicha.setGravidez(false);
        }

        while (true) {
            try {
                System.out.println("Idade: ");
                novaFicha.setIdade(scanner.nextInt());
                scanner.nextLine();
                break;
            } catch (Exception e) {
                scanner.nextLine();
                System.out.println("Insira a idade em forma númerica");
            }
        }
        while (true) {
            try {
                System.out.println("Peso: ");
                novaFicha.setPeso(scanner.nextDouble());
                scanner.nextLine();
                break;
            } catch (Exception e) {
                scanner.nextLine();
                System.out.println("Insira o peso em forma númerica");
            }
        }
        while (true) {
            try {
                System.out.println("Altura: ");
                novaFicha.setAltura(scanner.nextDouble());
                scanner.nextLine();
                break;
            } catch (Exception e) {
                scanner.nextLine();
                System.out.println("Insira a altura em forma númerica");
            }
        }
        System.out.println("Tipo sanguíneo: ");
        novaFicha.setTipoSanguineo(scanner.nextLine());
        System.out.println("Possui alguma doença ou condição especial?\n\rSe sim quais? ");
        novaFicha.setCondicoes(scanner.nextLine());
        System.out.println("Possui alergia a algum medicamento ou outos?\n\rSe sim quais? ");
        novaFicha.setAlergias(scanner.nextLine());
        while (true) {
            try {


                System.out.println("Fuma? S/N");
                var fuma = scanner.nextLine();

                if (fuma.equalsIgnoreCase("s")) {
                    novaFicha.setTabagismo(true);
                    break;
                }
                else if (fuma.equalsIgnoreCase("n")) {
                    novaFicha.setTabagismo(false);
                    break;
                } else {
                    throw new RuntimeException();
                }
            }

            catch (Exception e){
                System.out.println("Digite 'S' se fuma ou 'N' se não fuma");
            }
        }
        while (true) {
            try {


                System.out.println("vicío em alcool? S/N");
                var fuma = scanner.nextLine();

                if (fuma.equalsIgnoreCase("s")) {
                    novaFicha.setAlcool(true);
                    break;
                }
                else if (fuma.equalsIgnoreCase("n")) {
                    novaFicha.setAlcool(false);
                    break;
                } else {
                    throw new RuntimeException();
                }
            }

            catch (Exception e){
                System.out.println("Digite 'S' se possui vicío em alcool ou 'N' se não ");
            }
        }
        paciente.setFichaMedica(novaFicha);


    }

    //metodo para atualizar uma ficha medica
    public  FichaMedica cadastrarFicha(FichaMedica fichaMedica) {
        var scanner = new Scanner(System.in);
       if (fichaMedica.getSexo().equalsIgnoreCase("f")){
           while (true) {
               try {


                   System.out.println("Está gravida? S/N");
                   var gravida = scanner.nextLine();

                   if (gravida.equalsIgnoreCase("s")) {
                       fichaMedica.setGravidez(true);
                       break;
                   }
                   else if (gravida.equalsIgnoreCase("n")) {
                       fichaMedica.setGravidez(false);
                       break;
                   } else {
                       throw new RuntimeException();
                   }
               }

               catch (Exception e){
                   System.out.println("Digite 'S' se estiver grávida ou 'N' se não estiver");
               }
           }
       }

        while (true) {
            try {
                System.out.println("Peso: ");
                fichaMedica.setPeso(scanner.nextDouble());
                scanner.nextLine();
                break;
            } catch (Exception e) {
                scanner.nextLine();
                System.out.println("Insira o peso em forma númerica");
            }
        }
        while (true) {
            try {
                System.out.println("Altura: ");
                fichaMedica.setAltura(scanner.nextDouble());
                scanner.nextLine();
                break;
            } catch (Exception e) {
                scanner.nextLine();
                System.out.println("Insira a altura em forma númerica");
            }
        }
        System.out.println("Tipo sanguíneo: ");
        fichaMedica.setTipoSanguineo(scanner.nextLine());
        System.out.println("Possui alguma doença ou condição especial?\n\rSe sim quais? ");
        fichaMedica.setCondicoes(scanner.nextLine());
        System.out.println("Possui alergia a algum medicamento ou outos?\n\rSe sim quais? ");
        fichaMedica.setAlergias(scanner.nextLine());
        while (true) {
            try {


                System.out.println("Fuma? S/N");
                var fuma = scanner.nextLine();

                if (fuma.equalsIgnoreCase("s")) {
                    fichaMedica.setTabagismo(true);
                    break;
                }
                else if (fuma.equalsIgnoreCase("n")) {
                    fichaMedica.setTabagismo(false);
                    break;
                } else {
                    throw new RuntimeException();
                }
            }

            catch (Exception e){
                System.out.println("Digite 'S' se fuma ou 'N' se não fuma");
            }
        }
        while (true) {
            try {


                System.out.println("vicío em alcool? S/N");
                var fuma = scanner.nextLine();

                if (fuma.equalsIgnoreCase("s")) {
                    fichaMedica.setAlcool(true);
                    break;
                }
                else if (fuma.equalsIgnoreCase("n")) {
                    fichaMedica.setAlcool(false);
                    break;
                } else {
                    throw new RuntimeException();
                }
            }

            catch (Exception e){
                System.out.println("Digite 'S' se possui vicío em alcool ou 'N' se não ");
            }
        }

                 return fichaMedica;

    }


    @Override
    public String toString() {
        return
                "idade=" + getIdade() +
                ", sexo='" + getSexo() + '\'' +
                ", gravidez=" + isGravidez() +'\'' +
                "alergias='" + alergias + '\'' +
                ", condicoes='" + condicoes + '\'' +
                ", tipoSanguineo='" + tipoSanguineo + '\'' +
                ", peso=" + peso +
                ", altura=" + altura +
                ", tabagismo=" + tabagismo +
                ", alcool=" + alcool;
    }
}
